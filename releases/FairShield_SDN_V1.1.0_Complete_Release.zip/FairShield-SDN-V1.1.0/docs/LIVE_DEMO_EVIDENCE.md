# FairShield-SDN — Live Mininet / Open vSwitch Demo Evidence

**Evidence date:** 12 November 2026  
**Environment:** Ubuntu on WSL, Mininet 2.3.0, Open vSwitch 2.17.12, OS-Ken / OpenFlow 1.3  
**Scope:** Isolated six-host Mininet lab. The high-rate test used one UDP source (`h1`, 10.0.0.1); it is a controlled attack-like stress test, not a distributed real-world DDoS event.

> Evidence note: The values below are transcribed from terminal output shared during the live demonstration. No raw terminal screenshot or pcap was collected in that session, so this file is a structured transcript, not a claim that image artifacts were captured.

## 1. Environment and connectivity

- Controller process ran as PID `12398` and listened on TCP port `6653`.
- Open vSwitch controller entry `tcp:127.0.0.1:6653` reported `is_connected: true` and state `ACTIVE`.
- Mininet nodes: `c0 h1 h2 h3 h4 h5 h6 s1`.
- `pingall` completed with `0% dropped (30/30 received)`.
- Open vSwitch version reported: `2.17.12`.

## 2. Normal UDP baseline

Command executed from the Mininet prompt:

```bash
h1 python3 /home/shubhada/projects/fairshield_sdn/mininet/udp_traffic.py send --dst 10.0.0.5 --port 9000 --pps 100 --duration 10 --size 1000
```

Sender output:

```text
sent=1000 average_pps=100.0 average_kbps=800.0
```

Receiver log samples included approximately 100 packets/s and 800 kbps, for example:

```text
received=100 pps=100.0 kbps=799.9
received=101 pps=100.0 kbps=800.1
received=100 pps=100.0 kbps=800.0
```

This confirms normal UDP delivery during the baseline interval.

## 3. High-rate attack-like traffic and controller decision

A bounded sender was launched from `h1` to the sink on `h5` with the following configuration:

```bash
h1 python3 /home/shubhada/projects/fairshield_sdn/mininet/udp_traffic.py send --dst 10.0.0.5 --port 9000 --pps 1000 --duration 60 --size 200
```

The controller log reported source `10.0.0.1` repeatedly classified as `RATE_LIMIT`. Representative observations:

- Score: `0.90`.
- Packet rate: approximately `915–1002 pps`.
- Observed bit rate: approximately `1.77–1.94 Mbps`.
- Mean packet size reported by flow counters: approximately `242 bytes`.
- Admitted and allocated rate: `1500.0 kbps`.
- Reasons included high packet rate, small mean packet size, and high bit rate.

The controller logged the following requests:

```text
METER_REQUEST action=ADD source=10.0.0.1 meter_id=1 rate=1500 kbps
METER_RULE_REQUEST source=10.0.0.1 meter_id=1 table=0 priority=40000
...
METER_DELETE_REQUEST source=10.0.0.1 meter_id=1
```

## 4. OpenFlow meter configuration and counters

Open vSwitch meter configuration:

```text
meter=1 kbps burst bands=
type=drop rate=1500 burst_size=150
```

Meter statistics captured during the high-rate interval:

| Counter | Value |
|---|---:|
| Meter ID | 1 |
| Meter duration | 47.031 s |
| Packets entering meter | 47,031 |
| Bytes entering meter | 11,381,502 |
| Drop-band packets | 10,515 |
| Drop-band bytes | 2,544,630 |

The drop-band packet counter is approximately **22.36%** of the packets counted as entering the meter in that statistics snapshot. This ratio describes the meter counters for that observation only; it is not an end-to-end packet-loss rate and must not be reported as such.

## 5. Meter cleanup

After the controller requested deletion:

- `dump-meters s1` returned an empty meter configuration list.
- `dump-flows s1 table=0` showed only the default `priority=0 actions=goto_table:1` rule; the source-specific meter rule was no longer present.

A table-1 forwarding entry had an `idle_timeout=60`. At one point after the test, the normal UDP forwarding entry had expired and only the controller fallback remained. Running `pingall` refreshed forwarding/learning state; the subsequent recovery test delivered traffic successfully. Therefore, describe recovery as **verified after forwarding-state refresh**, not as a fully autonomous immediate restoration guarantee.

## 6. Normal UDP recovery after cleanup

After meter cleanup and a successful `pingall`, the same 100 PPS / 1000-byte UDP test was run again.

Sender output:

```text
sent=1000 average_pps=100.0 average_kbps=800.0
```

Receiver log showed sustained values around 100 PPS and 800 kbps, including:

```text
received=100 pps=100.0 kbps=799.8
received=101 pps=100.0 kbps=800.1
received=100 pps=100.0 kbps=800.0
received=100 pps=100.0 kbps=800.0
```

This verifies successful normal UDP delivery after the meter was removed and forwarding state refreshed.

## 7. What this live evidence proves — and does not prove

**Supported by the observed lab output:**

1. The OS-Ken controller connected to the OVS switch through OpenFlow 1.3.
2. The six-host Mininet topology had full ping reachability.
3. Normal UDP traffic reached the sink at approximately the configured rate.
4. The live controller classified the high-rate source as `RATE_LIMIT` and requested a 1500 kbps meter.
5. OVS reported meter input counters and drop-band counters greater than zero.
6. The meter and source-specific table-0 rule were absent after cleanup.
7. Normal UDP traffic reached the sink again after a forwarding-state refresh.

**Not established by this live test:**

- Multi-source distributed DDoS resistance; only one high-rate UDP source was used in this particular test.
- A live controlled comparison against no-defense and static-threshold baselines.
- End-to-end packet-loss, latency, jitter, physical-link goodput, or controller CPU impact.
- A live controller `ALLOW` log for the recovery interval.
- Production readiness or generalization to real Internet traffic.

## 8. Recommended evidence screenshots for the final presentation

For a later rehearsal, capture these directly from the actual terminals:

1. `nodes`, `pingall`, and `ovs-vsctl list Controller` showing `is_connected: true`.
2. Controller `RATE_LIMIT` and `METER_REQUEST` lines.
3. `ovs-ofctl -O OpenFlow13 dump-meters s1` while the attack is active.
4. `ovs-ofctl -O OpenFlow13 meter-stats s1` while the attack is active.
5. `dump-meters` after cleanup showing no configured meters.
6. Receiver output after the post-cleanup normal test.

Do not fabricate screenshots from the transcript. Keep these as a follow-up capture task if visual evidence is required by the evaluator.
