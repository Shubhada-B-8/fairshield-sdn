# Evidence and deployment document index

- `PROJECT_REPORT.md` — consolidated technical report.
- `EXPERIMENTS.md` — synthetic experiment design, results and live findings.
- `LIVE_DEMO_EVIDENCE.md` — transcribed observed Mininet/OVS outputs and evidence boundaries.
- `DEMO_RUNBOOK.md` — existing repeatable command-by-command demo guide.
- `FACULTY_DEPLOYMENT_GUIDE.md` — detailed clean-start deployment procedure for Ubuntu/WSL.
- `FACULTY_DEMO_CHECKLIST.md` — live rehearsal, evidence-capture and explanation checklist.
- `ARCHITECTURE.md` — component and OpenFlow pipeline description.
- `figures/` — charts from the saved synthetic simulator summary and architecture diagram.

Keep simulator results and live lab counters in separate tables; they measure different things. The live evidence file is a transcription of user-shared terminal output, not a collection of raw terminal screenshots.
