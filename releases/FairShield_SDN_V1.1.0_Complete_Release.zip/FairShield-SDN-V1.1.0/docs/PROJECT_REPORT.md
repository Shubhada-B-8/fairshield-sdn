# FairShield-SDN: Adaptive DDoS Detection and Fairness-Aware Traffic Management

**Project report — research prototype v1.1**  
**Live lab validation updated:** 12 November 2026

## Abstract

FairShield-SDN is an educational research prototype that combines rule-based traffic anomaly indicators, source-specific admission caps and weighted max-min bandwidth allocation in a Software-Defined Networking (SDN) setting. The project has two separate evaluation paths. First, a deterministic Python simulator compares no defense, a static packet-rate threshold and FairShield across normal, DDoS-like, flash-crowd and mixed synthetic traffic. Second, an OS-Ken/OpenFlow 1.3 adapter was exercised in a six-host Mininet/Open vSwitch lab to verify controller connectivity, source-meter installation, switch-side drop counters, meter cleanup and post-cleanup normal UDP delivery. In the saved 30-window synthetic run, FairShield mitigated 99.4% of attack demand in both DDoS-like and mixed scenarios; it achieved the highest legitimate preservation and fairness in the mixed scenario, while the static threshold performed better on some DDoS-only metrics. The live lab observed a 1500 kbps meter and 10,515 drop-band packets out of 47,031 meter-input packets in one 47.031-second statistics snapshot. These results support a working academic prototype, not claims of production-grade or real-Internet DDoS protection.

**Keywords:** Software-Defined Networking, OpenFlow 1.3, DDoS mitigation, traffic admission control, weighted max-min fairness, Open vSwitch, Mininet.

## 1. Introduction and problem statement

A shared network bottleneck can become congested when one or more traffic sources offer more packets or bits than the network can carry. DDoS mitigation systems need to suppress harmful traffic while preserving service for legitimate users. A simple high-rate threshold can mistakenly restrict legitimate bursts such as flash crowds. FairShield explores a combined policy: classify suspicious source profiles, cap their admitted demand, and allocate the remaining configured capacity among admitted sources using weighted max-min fairness.

The project is intentionally scoped as a single-switch research prototype. It contains an offline simulator and a separate live SDN adapter. The two paths use different available features and are not presented as the same detector.

## 2. Objectives

1. Build an interpretable flow-level traffic detector.
2. Compare no-defense, static-threshold and FairShield policies in repeatable synthetic scenarios.
3. Allocate constrained capacity with weighted max-min fairness and measure Jain satisfaction fairness.
4. Connect a controller to an OpenFlow 1.3 switch and enforce per-source rate caps with OpenFlow meters.
5. Preserve clear evidence boundaries between simulated performance and live switch behavior.

## 3. System architecture

The main source modules are `models.py`, `detector.py`, `fairness.py`, `controller.py`, `sdn_policy.py`, `ryu_app.py`, `simulator.py`, `reporting.py`, `dashboard.py`, `socket_lab.py`, `ml_optional.py` and `cli.py`.

![Architecture](figures/architecture.png)

The offline path generates synthetic flow observations, calculates a suspiciousness score, applies an admission cap and allocates capacity. The dashboard displays experiment outputs. The live path uses OS-Ken and OpenFlow 1.3 to poll switch flow counters and install meters in Open vSwitch.

### 3.1 Offline detector

The simulator detector uses synthetic source-level features including packet rate, SYN ratio, destination-port fan-out and bit rate. Ground-truth scenario labels are used for evaluation, not as detector inputs. Its score is interpretable and rule based.

### 3.2 Live detector

The live adapter polls OpenFlow table-1 counters every five seconds and derives packet rate, bit rate, mean packet size and destination-port fan-out. Standard aggregate flow counters do not reveal TCP SYN flags, so the live adapter uses a distinct high-rate/small-packet heuristic. In the demonstrated configuration, controller logs identified source `10.0.0.1` with score 0.90 and rate-limited it at a 1500 kbps admitted rate.

### 3.3 Fairness-aware allocation

Suspicious source demand is capped before capacity allocation. Weighted max-min allocation distributes the configured policy budget among admitted sources without exceeding each source's admitted demand. Jain's fairness index is used as an evaluation metric. The configured live 10,000 kbps capacity budget is a policy parameter, not a measurement of the physical link capacity.

### 3.4 OpenFlow enforcement

The live pipeline uses table 0 for source-specific meter rules and a default `goto_table:1` rule. Table 1 provides learning-switch forwarding. OpenFlow meters apply a drop band when traffic exceeds the configured rate. The controller can add, modify or remove meters and associated source rules.

## 4. Implementation environment

The live demo was run in Ubuntu on WSL with Mininet 2.3.0, Open vSwitch 2.17.12, OS-Ken and OpenFlow 1.3. The topology contains six hosts (`h1`–`h6`), one switch (`s1`) and a controller (`c0`). Host `h5` acted as the UDP sink at `10.0.0.5:9000`; `h1` was the controlled high-rate source at `10.0.0.1`.

The controller startup script binds its OpenFlow listener to port 6653. The OVS controller entry `tcp:127.0.0.1:6653` reported `is_connected: true` and state `ACTIVE` during the demonstration.

## 5. Offline synthetic experimental design

The saved reproducibility run used seed 7, 30 windows and a configured bottleneck capacity of 500 packets per second. The same synthetic traffic was evaluated with three policies:

- **No defense:** no attack-specific rate restriction.
- **Static threshold:** fixed packet-rate threshold.
- **FairShield:** suspicious source demand caps followed by weighted max-min allocation.

Scenarios were normal traffic, DDoS-like traffic, flash crowd and mixed traffic. The simulator output is deterministic for the saved seed and is stored under `outputs/reproducibility_seed7_30/`.

## 6. Metrics

- **Legitimate preservation:** legitimate delivered packets per second divided by legitimate offered packets per second.
- **Policy-level attack mitigation:** one minus attack admitted packets per second divided by attack offered packets per second. This is measured before bottleneck contention and is not end-to-end packet loss.
- **Jain fairness:** computed over legitimate sources' delivered/offered satisfaction ratios.
- **Precision, recall and F1:** detector classification metrics against synthetic scenario labels.
- **Delivered PPS:** modeled delivered packet throughput.

## 7. Synthetic experiment results

### 7.1 DDoS-like scenario

| Policy | Legitimate preserved | Attack mitigated | Jain fairness | F1 | Delivered PPS |
|---|---:|---:|---:|---:|---:|
| No defense | 70.2% | 0.0% | 0.998 | 1.000 | 500.00 |
| Static threshold | 99.9% | 100.0% | 1.000 | 1.000 | 440.17 |
| FairShield | 99.0% | 99.4% | 1.000 | 1.000 | 466.27 |

Static threshold is slightly higher on legitimate preservation and policy-level attack suppression in this generated DDoS-only case. FairShield still suppresses 99.4% of attack demand and delivers more PPS than the static threshold in this run.

### 7.2 Flash-crowd scenario

| Policy | Legitimate preserved | Attack mitigated | Jain fairness | F1 | Delivered PPS |
|---|---:|---:|---:|---:|---:|
| No defense | 25.4% | N/A | 0.694 | 0.000 | 500.00 |
| Static threshold | 17.1% | N/A | 0.500 | 0.000 | 335.57 |
| FairShield | 25.4% | N/A | 0.694 | 0.000 | 500.00 |

The static threshold causes substantial collateral restriction in this flash-crowd simulation. FairShield matches no defense for this generated benign burst, indicating that its multi-indicator rule avoids the static threshold's false-positive restriction. Congestion still limits legitimate preservation.

### 7.3 Mixed scenario

| Policy | Legitimate preserved | Attack mitigated | Jain fairness | F1 | Delivered PPS |
|---|---:|---:|---:|---:|---:|
| No defense | 27.3% | 0.0% | 0.821 | 1.000 | 500.00 |
| Static threshold | 35.1% | 100.0% | 0.714 | 1.000 | 449.17 |
| FairShield | 36.7% | 99.4% | 0.827 | 1.000 | 500.00 |

In this generated mixed case, FairShield has the highest legitimate preservation and fairness among the policies while suppressing 99.4% of attack demand.

### 7.4 Figures

**Figure 1.** Legitimate traffic preservation by scenario.

![Legitimate preservation](figures/legitimate_preservation.png)

**Figure 2.** Policy-level attack-demand mitigation.

![Attack mitigation](figures/attack_mitigation.png)

**Figure 3.** Jain satisfaction fairness.

![Fairness](figures/jain_fairness.png)

**Figure 4.** Delivered throughput.

![Delivered PPS](figures/delivered_pps.png)

### 7.5 Interpretation and reproducibility caveat

The saved synthetic F1 scores of 1.0 in DDoS-like and mixed cases reflect deliberately separable generated features, not expected real-world model accuracy. A normal scenario contains no attacks, so attack mitigation and detector F1 do not provide useful comparative evidence there. All simulation values must be labelled synthetic.

## 8. Live Mininet / Open vSwitch validation

The live experiment is separate from the synthetic comparisons. It used one high-rate UDP source, not multiple attacking hosts.

### 8.1 Topology and connectivity

Mininet listed `c0 h1 h2 h3 h4 h5 h6 s1`. The OpenFlow 1.3 controller target was active. `pingall` reported `0% dropped (30/30 received)`.

### 8.2 Normal traffic baseline

A 100 PPS, 1000-byte UDP sender transmitted 1000 packets to `h5`. The sender reported `average_kbps=800.0`; receiver log samples showed approximately 100 PPS and 800 kbps. This confirmed the sink was reachable and recording normal traffic.

### 8.3 High-rate source and meter enforcement

A controlled `h1` traffic generator was configured for 1000 PPS, 60 seconds and 200-byte payloads. The controller identified source `10.0.0.1` with a score of 0.90; representative observations were 915–1002 PPS and 1.77–1.94 Mbps, with a mean packet size around 242 bytes in flow counters. It logged `RATE_LIMIT`, an admitted rate of 1500 kbps, and meter add/rule requests.

Open vSwitch showed meter 1 with a drop band configured at 1500 kbps and burst size 150. A statistics snapshot after 47.031 seconds showed:

| Meter statistic | Observed value |
|---|---:|
| Packets entering meter | 47,031 |
| Bytes entering meter | 11,381,502 |
| Drop-band packets | 10,515 |
| Drop-band bytes | 2,544,630 |
| Drop-band packet share of meter inputs | 22.36% |

The 22.36% ratio is a calculation from the meter counters for that snapshot. It is not the network's end-to-end loss rate and should not be described as such.

### 8.4 Cleanup and recovery

The controller later logged `METER_DELETE_REQUEST`. Subsequent OVS checks showed an empty meter configuration and no source-specific table-0 meter rule. A normal-flow rule with `idle_timeout=60` had expired during the gap, leaving the controller fallback. The demo operator ran `pingall` to refresh learned forwarding state before repeating the normal test. The sender again reported 1000 packets at 100 PPS / 800 kbps, and the receiver recorded approximately 100 PPS / 800 kbps.

This confirms meter cleanup and successful normal UDP delivery after forwarding-state refresh. It does not prove autonomous immediate restoration without that refresh.

The full transcribed record and commands are in `docs/LIVE_DEMO_EVIDENCE.md`; the repeatable procedure is in `docs/DEMO_RUNBOOK.md`.

## 9. Dashboard and supporting demonstrations

The browser dashboard (`dashboard.py`) provides scenario/window controls, KPI cards and policy comparison tables for the **offline synthetic simulator**. The saved dashboard screenshot is from a DDoS-like 30-window simulation and shows 99.0% legitimate preservation, 99.4% attack mitigation, 1.00 Jain fairness and 1.00 F1 for FairShield. It is not a real-time Mininet dashboard.

The socket lab demonstrates TCP/UDP client-server telemetry. The optional Random Forest module uses synthetic data and is not a validated live detector.

## 10. Automated testing

The project test suite was rerun from the extracted ZIP with:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

**Result: 16 tests passed.** Tests cover detector behavior, fairness allocation, simulator metrics, TCP/UDP socket round trips and live policy decisions including recovery from attack-like to normal traffic. These are automated software tests; they are distinct from the live OVS meter demonstration.

## 11. Limitations

1. Synthetic scenarios are not real packet traces or production traffic.
2. The live test used one UDP source; a multi-source DDoS scenario has not been validated live.
3. No controlled live comparison among no-defense, static-threshold and FairShield policies has been completed.
4. The live adapter uses packet rate, mean packet size, bit rate and destination-port fan-out; it does not use TCP SYN-flag features because standard aggregate OpenFlow counters do not expose them.
5. No physical link capacity, latency, jitter, end-to-end packet-loss rate, CPU consumption, table pressure or rule-installation latency was measured.
6. Recovery in the observed demo required `pingall` to refresh a learned forwarding entry after idle expiry. Hysteresis and hold-down behavior are not implemented.
7. The configured 10,000 kbps policy budget is not a measured physical link capacity.
8. Optional ML code is based on synthetic data and has no representative real-world validation.
9. The controller is a single-switch educational prototype, not a production security appliance.

## 12. Conclusion and future work

FairShield-SDN now has a reproducible synthetic policy simulator and a demonstrated live OpenFlow meter-enforcement path in an isolated Mininet lab. The synthetic results show a useful trade-off: the static threshold can be stronger in a DDoS-only simulation, while FairShield avoids static-threshold false positives in the flash-crowd case and performs best on legitimate preservation and fairness in the saved mixed case. The live evidence confirms that the controller can request a 1500 kbps source meter, that OVS records drop-band counters, that meter cleanup occurs, and that normal UDP traffic can be delivered again after forwarding state is refreshed.

The next research work is to collect raw screenshots/pcaps, run multi-source live traffic, compare all policies live under identical workloads, capture throughput/latency/CPU and rule-installation measurements, repeat trials across seeds and parameters, and add sensitivity/ablation analysis. These steps are required before making broader claims about detection efficacy or production use.
