# Changelog

## 1.1.0 — November 2026 (frozen V1 release)

- Added an interpretable live SDN source policy using packet rate, mean packet size, bit rate and destination-port fan-out.
- Added an OS-Ken/Ryu-compatible OpenFlow 1.3 two-table controller with per-source meter add/modify/remove and weighted max-min kbit/s allocation.
- Added a six-host Mininet topology and bounded UDP sender/sink tools.
- Added offline synthetic traffic scenarios: normal, DDoS-like, flash crowd and mixed.
- Added policy comparison among no defense, static threshold and FairShield.
- Added experiment outputs, CSV/JSON reporting, browser dashboard, socket-lab demonstrations and optional synthetic-data Random Forest example.
- Added faculty deployment guide, preflight check, live demo runbook, evidence transcript, project report, presentation and viva preparation.
- Verified 16 automated unit tests and a limited live Mininet/OVS meter-enforcement demonstration.

## Evidence and scope notes

- Offline simulator results are synthetic and are not measurements of a production or physical network.
- The live Mininet demonstration used one high-rate UDP source; it is not a distributed multi-source DDoS benchmark.
- The live adapter uses aggregate OpenFlow counters and does not inspect TCP SYN flags.
- The observed 10,515 drop-band packets out of 47,031 meter-input packets is a meter-counter ratio for one snapshot, not end-to-end packet loss.
- Post-cleanup normal UDP delivery was verified after `pingall` refreshed learned forwarding state following idle expiry.
- This V1 release is preserved as an academic prototype. Version 2 research changes should be developed separately on a branch or copy.

## Historical note

Earlier development notes mentioned 15 tests and pending live validation. Those notes were superseded by the V1 verification above: 16 tests passed and limited live Mininet/OVS validation was completed.
