"""FairShield-SDN: fairness-aware SDN DDoS research prototype."""
__version__ = "1.1.0"
