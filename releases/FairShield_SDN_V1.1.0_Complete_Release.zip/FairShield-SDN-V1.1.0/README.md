# FairShield-SDN

**An adaptive SDN research prototype for DDoS detection, fairness-aware traffic admission, and mitigation.**

FairShield-SDN is a reproducible Computer Networks project. It demonstrates how an SDN-style controller can observe traffic-flow features, identify suspicious source behavior, cap admitted demand from flagged sources, and allocate the remaining bottleneck capacity using weighted max-min fairness.

> **Important scope statement:** The core implementation is a deterministic, offline network/flow simulator. An optional OS-Ken/Ryu-compatible OpenFlow 1.3 controller and Mininet topology are included for a Linux lab demonstration. The adapter is a prototype, not a hardened production security appliance. Results produced by the simulator are synthetic and must not be reported as measured real-network performance.

## What is included

- Traffic generator for normal traffic, volumetric DDoS-like sources, flash-crowd traffic, and mixed traffic.
- Interpretable multi-indicator rule detector using packet rate, SYN ratio, destination-port fan-out, and bit rate.
- FairShield policy: detection followed by attacker demand capping and weighted max-min allocation of the link budget.
- Baselines: no defense and a fixed-threshold drop policy.
- Metrics: legitimate traffic preservation, policy-level attack suppression (measured before bottleneck contention), delivered attack throughput, Jain satisfaction-fairness index, precision, recall, F1, and delivered throughput.
- Reproducible experiment runner that saves JSON and CSV results.
- Local browser dashboard using only the Python standard library.
- Optional Random Forest training demonstration (not required by the core project).
- Optional OS-Ken/Ryu-compatible OpenFlow 1.3 adapter with per-source meters, weighted max-min rate allocation, and a Mininet topology for a Linux environment.
- Unit tests and patent-readiness / invention-disclosure notes.

## Architecture

```text
             Simulated hosts / Mininet hosts
                         |
                  Ethernet / IP flows
                         |
              Open vSwitch (optional lab)
                         |
               OpenFlow 1.3 statistics
                         |
              FairShield SDN controller
          +--------------+---------------+
          |              |               |
       Monitor        Detector       Policy engine
     flow counters   multi-feature    attacker cap
                     rule score       + max-min share
          |              |               |
          +--------------+---------------+
                         |
                 mitigation decision
             ALLOW / RATE_LIMIT / DROP
                         |
               evaluation and dashboard
```

## Requirements

- Python 3.10 or newer.
- Windows, macOS, or Linux for the core simulator/dashboard.
- No third-party package is required for the core implementation.
- Optional ML: NumPy, scikit-learn, and joblib.
- Optional live SDN lab: Ubuntu/Linux, Mininet, Open vSwitch, and OS-Ken (see `mininet/README.md`).

## Quick start — Windows PowerShell

Open PowerShell in the extracted project folder:

```powershell
py -3 --version
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
```

If PowerShell blocks activation, use the current session only:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Run all experiments:

```powershell
fairshield demo --windows 30 --seed 7 --capacity 500 --out outputs
```

Run only the mixed scenario:

```powershell
fairshield simulate --scenario mixed --windows 30 --seed 7 --out outputs
```

Start the dashboard:

```powershell
fairshield dashboard --host 127.0.0.1 --port 8080
```

Open `http://127.0.0.1:8080` in your browser. Stop it with `Ctrl+C`.

Run automated tests:

```powershell
python -m unittest discover -s tests -v
```

## Quick start — Linux / macOS / WSL

```bash
python3 --version
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .

fairshield demo --windows 30 --seed 7 --capacity 500 --out outputs
fairshield dashboard
```

In another terminal, run tests:

```bash
source .venv/bin/activate
python -m unittest discover -s tests -v
```

## Run without installing the CLI entry point

From the repository root:

```bash
python -m pip install -e .
python -m fairshield.cli demo --windows 30
```

## Experiment commands

```bash
# Compare all three policies in every traffic scenario
fairshield demo --windows 60 --seed 7 --capacity 500 --out outputs

# DDoS-focused scenario
fairshield simulate --scenario ddos --windows 60 --out outputs

# Flash-crowd scenario (useful to discuss false positives)
fairshield simulate --scenario flash_crowd --windows 60 --out outputs

# Normal baseline
fairshield simulate --scenario normal --windows 60 --out outputs
```

Generated files:

- `outputs/summary.csv` — one row per scenario/policy.
- `outputs/summary.json` — same results in JSON.
- `outputs/traffic_trace.csv` — source-level per-window decisions, scores, admitted demand, allocated rate, and goodput.

## TCP/IP socket lab (real local TCP and UDP traffic)

The companion socket service demonstrates actual transport-layer communication using Python sockets. It accepts newline-delimited JSON over TCP or one JSON datagram over UDP, evaluates the flow record, and returns a detection decision.

Terminal 1 — start the TCP service:

```bash
python -m fairshield.socket_lab tcp-server --host 127.0.0.1 --port 9100
```

Terminal 2 — send a suspicious TCP telemetry sample:

```bash
python -m fairshield.socket_lab tcp-client --host 127.0.0.1 --port 9100 --pps 700 --syn-ratio 0.95 --ports 16
```

For UDP, use two other terminals:

```bash
python -m fairshield.socket_lab udp-server --host 127.0.0.1 --port 9101
python -m fairshield.socket_lab udp-client --host 127.0.0.1 --port 9101 --pps 45 --syn-ratio 0.04 --ports 1
```

This socket lab is a small transport demonstration; OpenFlow is the southbound SDN protocol in the optional Mininet/OS-Ken adapter.

## Optional ML experiment

The base project does not require ML. To train a Random Forest on the project's generated synthetic feature data:

```bash
python -m pip install -e ".[ml]"
python -m fairshield.ml_optional --samples-per-class 500 --output models/fairshield_rf.joblib
```

The resulting model is a demonstration trained on synthetic data. Do not describe its score as real-world accuracy or deploy it as a security classifier without training and validating on a suitably licensed, representative dataset and testing for data leakage, class imbalance, and distribution shift.

## Faculty deployment and live evaluation

For the tested Ubuntu/WSL deployment, follow [`docs/FACULTY_DEPLOYMENT_GUIDE.md`](docs/FACULTY_DEPLOYMENT_GUIDE.md). Before the evaluation, run the read-only environment check with `./scripts/preflight_sdn_lab.sh`. Use [`docs/FACULTY_DEMO_CHECKLIST.md`](docs/FACULTY_DEMO_CHECKLIST.md) to rehearse the controller, Mininet, OpenFlow meter, cleanup, and recovery sequence. The checklist distinguishes observed behavior from screenshots that still need to be captured during the faculty rehearsal.

## Optional live SDN demonstration

See [`mininet/README.md`](mininet/README.md). The controller prefers OS-Ken (the maintained Ryu fork) and includes a Ryu import fallback. Its OpenFlow 1.3 two-table pipeline applies per-source meters in table 0 and MAC-learning forwarding in table 1. Every five seconds it derives per-source rates from OpenFlow counters, applies a high-rate/small-packet heuristic, caps flagged demand, computes weighted max-min allocations in kbit/s, and adds, modifies, or removes meters. This live detector is intentionally distinct from the offline detector because standard aggregate flow counters do not expose TCP SYN flags. The live controller has been exercised in the isolated six-host Mininet/OVS lab. See `docs/LIVE_DEMO_EVIDENCE.md` for observed meter and recovery evidence, and `docs/DEMO_RUNBOOK.md` for repeatable steps.

## Networking concepts demonstrated

| Concept | Where it appears |
|---|---|
| TCP/IP stack | IPv4 source/destination addressing; TCP/UDP destination-port flow matching in the OS-Ken/Ryu-compatible adapter |
| Ethernet / MAC layer | Open vSwitch data-plane switching in the optional Mininet topology |
| Network layer | IPv4 source-specific monitoring and mitigation |
| Transport layer | TCP/UDP destination-port observations; TCP SYN ratio in the simulator's flow telemetry |
| Client-server model | Mininet UDP sink/client plus TCP/UDP socket lab |
| SDN control/data-plane split | OS-Ken/Ryu-compatible controller communicates with Open vSwitch over OpenFlow 1.3 |
| Flow-based monitoring | Per-source packet/byte counters and derived rates |
| Congestion / fairness | Link-capacity constraint and weighted max-min allocation |

The OSI model is useful for explaining the design in your report, but the implementation is not a new OSI protocol. TCP/IP and OSI are conceptual models, not software dependencies that must be installed.

## Evaluation methodology and limitations

1. Every scenario uses a fixed random seed to make runs repeatable.
2. A source is treated as a DDoS source only in the synthetic ground-truth label. The detector itself does not read that label.
3. Each policy sees the same generated traffic sequence for a given scenario/seed.
4. The static baseline drops any source at or above 150 packets/second; this intentionally exposes the flash-crowd false-positive trade-off.
5. In the offline simulator, FairShield caps detector-flagged source demand at 5 packets/second and then uses max-min fairness. In the optional live SDN lab, a separate source policy caps suspicious sources at 1,500 kbit/s and applies weighted max-min allocation against a configured 10,000 kbit/s budget using OpenFlow meters.
6. Jain's index is computed over each legitimate source's average demand-satisfaction ratio, not raw throughput. This makes different offered rates more comparable.
7. The simulator assumes one-second measurement windows and a single bottleneck link. It does not model packet-level queues, TCP congestion-control dynamics, retransmissions, switch TCAM limits, or real controller latency.

These assumptions must appear in your final report. The next research step is validation with real packet traces and Mininet/Open vSwitch measurements, followed by repeated live baselines, parameter sensitivity and ablation tests.

## Suggested demo sequence

1. Show the architecture and identify the SDN control plane and data plane.
2. Run `fairshield simulate --scenario normal` and establish baseline behavior.
3. Run `fairshield simulate --scenario ddos` and compare no defense with FairShield.
4. Run `fairshield simulate --scenario flash_crowd` to show why a fixed packet-rate threshold can block legitimate burst traffic.
5. Run the mixed scenario and discuss legitimate preservation, attack mitigation, and Jain fairness together.
6. Open `outputs/summary.csv` and `outputs/traffic_trace.csv` to show the underlying evidence.
7. For an advanced demonstration, run the optional Mininet/OS-Ken/OpenFlow 1.3 lab in Ubuntu (the live network is a separate lab path; its observed integration evidence is recorded in `docs/LIVE_DEMO_EVIDENCE.md`).

## Project structure

```text
fairshield_sdn/
├── README.md
├── pyproject.toml
├── requirements.txt
├── scripts/
│   ├── setup_sdn_linux.sh
│   ├── start_sdn_controller.sh
│   └── start_mininet_lab.sh
├── src/fairshield/
│   ├── cli.py
│   ├── controller.py
│   ├── dashboard.py
│   ├── detector.py
│   ├── fairness.py
│   ├── ml_optional.py
│   ├── models.py
│   ├── reporting.py
│   ├── ryu_app.py
│   ├── sdn_policy.py
│   └── simulator.py
├── tests/test_core.py
├── tests/test_sdn_policy.py
├── mininet/
│   ├── fairshield_topology.py
│   ├── udp_traffic.py
│   └── README.md
└── docs/
    ├── ARCHITECTURE.md
    ├── EXPERIMENTS.md
    ├── INVENTION_DISCLOSURE_DRAFT.md
    └── PATENT_READINESS.md
```

## Safety / responsible use

All included attack traffic is synthetic. Use the optional Mininet lab only in an isolated environment you own or are authorized to test. The supplied controller is an educational prototype and should not be connected to a production network.

## License

MIT License — see `LICENSE`.

## One-command setup scripts

Windows PowerShell (from the extracted project folder):

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup_windows.ps1
```

Then start the dashboard:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start_dashboard_windows.ps1
```

Linux / Ubuntu / WSL:

```bash
bash scripts/setup_linux.sh
```

## Project report and IP preparation

- [`docs/PROJECT_REPORT.md`](docs/PROJECT_REPORT.md) — ready-to-edit academic project report with architecture, methodology, synthetic results, limitations and next experiments.
- [`docs/INVENTION_DISCLOSURE_DRAFT.md`](docs/INVENTION_DISCLOSURE_DRAFT.md) — preliminary technical disclosure scaffold for discussion with a patent professional.
- [`docs/PATENT_READINESS.md`](docs/PATENT_READINESS.md) — prior-art warning and filing-readiness checklist.

**Patent note:** This ZIP is a working research prototype and an invention-disclosure starting point, not a patent application, legal opinion, or assurance of grant. A broad SDN/DDoS detection idea is not enough by itself. Before public disclosure or filing, identify the specific human-conceived technical contribution, verify ownership and institutional rules, conduct a structured prior-art search, and consult a registered Indian patent agent/attorney.


## Live validation status

On 12 November 2026, the isolated Mininet/OVS lab verified the OpenFlow 1.3 controller connection, six-host connectivity, normal UDP delivery, controller `RATE_LIMIT` decision, a 1500 kbps OVS meter, nonzero drop-band counters, meter cleanup, and normal UDP delivery after a forwarding-state refresh. The demonstrated high-rate traffic used one source and should be described as a controlled attack-like UDP stress test, not a distributed DDoS benchmark. See [`docs/LIVE_DEMO_EVIDENCE.md`](docs/LIVE_DEMO_EVIDENCE.md) and [`docs/DEMO_RUNBOOK.md`](docs/DEMO_RUNBOOK.md).


## V1 release boundary and final-evaluation bundle

This repository preserves the FairShield-SDN V1.1.0 prototype. Do not treat the proposed adaptive-feedback V2 direction as implemented. The current code, saved simulator outputs, and live lab evidence describe V1 only.

For final evaluation, start with:

- `docs/FACULTY_DEPLOYMENT_GUIDE.md` — deployment setup and terminal sequence.
- `docs/FACULTY_DEMO_CHECKLIST.md` — faculty demonstration checklist.
- `docs/DEMO_RUNBOOK.md` — exact repeatable commands.
- `docs/LIVE_DEMO_EVIDENCE.md` — observed controller/OVS output and limits.
- `docs/PROJECT_REPORT.md` and `docs/FairShield_SDN_Project_Report.docx` — project report.
- `paper/FairShield_SDN_Research_Paper_Draft.docx` — separate research-paper draft; it requires author/institution details, supervisor review and any additional experiments requested before submission.
- `presentation/FairShield_SDN_Final_Presentation.pptx` — presentation deck.
- `docs/VIVA_PREPARATION.md` — oral examination preparation.
- `GITHUB_PUSH_GUIDE.md` — private GitHub repository setup and push commands.

The project is an academic prototype, not a production security appliance. Review the institution's IP policy before making the repository or manuscript public.
