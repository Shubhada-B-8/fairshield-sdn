# FairShield-SDN V1.1.0 Release Manifest

This package preserves the V1.1.0 project. No Version 2 algorithm or controller changes are included.

## Main deliverables
- `README.md` — project overview and commands
- `src/fairshield/` — source implementation
- `tests/` — automated tests
- `mininet/` and `scripts/` — live lab topology and startup tools
- `outputs/` — synthetic experiment outputs and validation record
- `docs/FairShield_SDN_Project_Report.docx` — project report
- `paper/FairShield_SDN_Research_Paper_Draft.docx` — separate research paper draft
- `presentation/FairShield_SDN_Final_Presentation.pptx` — presentation
- `docs/FACULTY_DEPLOYMENT_GUIDE.md` — deployment guide
- `docs/FACULTY_DEMO_CHECKLIST.md` — faculty demo checklist
- `docs/DEMO_RUNBOOK.md` — live demo commands
- `docs/LIVE_DEMO_EVIDENCE.md` — observed live results and limitations
- `docs/VIVA_PREPARATION.md` — viva preparation
- `GITHUB_PUSH_GUIDE.md` — private GitHub push commands
- `docs/LITERATURE_AND_PRIOR_ART_COMPARISON.md` — preliminary literature/patent map

## Important status
- Working prototype and isolated live meter enforcement were tested.
- Faculty demonstration has not yet been completed.
- Research paper is a draft for supervisor review and requires verified author/affiliation details.
- Repository push has not been performed; follow `GITHUB_PUSH_GUIDE.md`.
- Patent novelty and freedom-to-operate have not been established.
